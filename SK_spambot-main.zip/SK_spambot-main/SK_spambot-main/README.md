### 🌷𝐕𝐈𝐒𝐈𝐓𝐎𝐑𝐒🌷

<!--
**itszshivam/itszshivam** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.


<p align="center">
    <b>ᴠɪsɪᴛᴏʀs</b><br>
 -->    <img align="middle" src="https://profile-counter.glitch.me/itszshivam/count.svg" />
</p>

<h1 align="center"><b> 𝐂𝐘𝐁𝐄𝐑𝐃𝐑𝐀𝐆𝐎𝐍 𝙓 𝕾𝖕𝖆𝖒🔥</b></h1>

<h4 align="center"> 𝐓𝐇𝐄 𝐏𝐎𝐖𝐄𝐑𝐅𝐔𝐋 𝐒𝐏𝐀𝐌𝐁𝐎𝐓𝐒</h4>

<p align="center"><a href="https://t.me/cyberdragon2477"><img src="https://te.legra.ph/file/05707bfa4afeca2f9c330.jpg" width="400"></a></p>


> ⭐️ Thanks to everyone for using THIS cyberdragon SPAM BOT, That is the greatest pleasure we have !

<br>

- ⚠️ Do not forget to fork this repo. Else error can occur in deployment.

# ᴅᴇᴘʟᴏʏᴍᴇɴᴛ


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ʜᴇʀᴏᴋᴜ</b></summary>
<br>

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/Cyberdragon247/Cdspamer)
  
</details>


<details>
<summary><b>ᴅᴇᴘʟᴏʏ ᴛᴏ ᴋᴏʏᴇʙ</b></summary>
<br>

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=&branch=name&name=thealtron)
  
</details>


# Rᴇǫᴜɪʀᴇᴍᴇɴᴛs

- `10 BOT-TOKENS`

- `OWNER-ID`


# ꜱᴜᴘᴘᴏʀᴛ ✨
<a href="https://t.me/cyberdragonclub"><img src="https://img.shields.io/badge/Join-Telegram%20Channel-red.svg?logo=Telegram"></a>
